/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mini4sem;


/**
 *
 * @author sowra
 */
public class Mini4sem {
  
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Signup_Page signup =new Signup_Page();
         signup.show();
        
    }
    
}
